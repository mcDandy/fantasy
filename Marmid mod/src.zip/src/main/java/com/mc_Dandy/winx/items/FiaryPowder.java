package com.mc_Dandy.winx.items;

import net.minecraft.item.Item;

public class FiaryPowder extends Item {
	public FiaryPowder(String string){
		this.setCreativeTab(ModItems3.tabWinx);
		this.setMaxStackSize(255);
		this.setUnlocalizedName(string);
	}
}
