package com.mc_Dandy.marmid.blocks;

import net.minecraft.block.Block;

public final class ModBlocks {
	public static Block blueGlowstone;

    public static void createBlocks() {
    }
}